package application;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.google.gson.JsonSyntaxException;

import Modele.BDD;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class JukeboxController {

	
	@FXML
	private Button button1;
	@FXML
	private Button exportCSV;
	@FXML
	private TextField textFieldExportCSV;
	@FXML
	private Label labelExportCSV;
	@FXML
	private Label informationBDD;
	@FXML
	private TextField nomChanteur;
	@FXML
	private TextField nomAlbum;
	@FXML
	private Button addAlbum;
	@FXML
	private Button deleteAlbum;
	@FXML
	private Button supprimerChanteur;
	@FXML
	private TextField nomChanteurAjoutSuppr;
	@FXML
	private Label affichageTables;
	@FXML
	private Button affichageTablesButton;
	@FXML
	private TextField nomTablePourAffichage;
	@FXML
	private TextField recupNomChanteur;
	@FXML
	private TextArea textarea;
	@FXML
	private Button ajoutChanteur;
	@FXML
	private TextField tfNomChanteur;
	@FXML
	private TextField tfUsernameChanteur;
	
	BDD bdd;

	
	public void clickMe(ActionEvent e) throws JsonSyntaxException, ClassNotFoundException, IOException {
		this.bdd = new BDD();
		bdd.labelInformation(informationBDD,"Import de la base achevé avec succès");
	}
	
	public void clickMeExportCSVButton(ActionEvent e) throws InvocationTargetException, IOException, SQLException {
		
		this.bdd.csvPrintAlbum( correspondance(textFieldExportCSV.getText()) );
		
		System.out.println("Export terminé.");

	}
	
	public void labelInformation(Label lab, String string) {
		   lab.setText(string);
	   }
	
	
	public int correspondance(String nomChanteur) {
		int i=0;
		switch (nomChanteur) {
		
		case "Leanne Graham": 
			i = 1;
			break;
			
		case "Ervin Howell": 
			i = 2;
			break;
		
		case "Clementine Bauch": 
			i = 3;
			break;
		
		case "Patricia Lebsack": 
			i = 4;
			break;
		case "Chelsey Dietrich": 
			i = 5;
			break;
		case "Mrs. Dennis Schulist": 
			i = 6;
			break;
		case "Kurtis Weissnat": 
			i = 7;
			break;
		case "Nicholas Runolfsdottir V": 
			i = 8;
			break;
		case "Glenna Reichert": 
			i = 9;
			break;
		case "Clementina DuBuque": 
			i = 10;
			break;
		}
		return i;
	}
		
	public void clickMeAddAlbum(ActionEvent e) throws JsonSyntaxException, ClassNotFoundException, IOException, SQLException {
		String nomChanteurAdd = nomChanteur.getText();
		String nomAlbumAdd = nomAlbum.getText();
		
		
		if ( bdd.albumExist( correspondance(nomChanteurAdd) , nomAlbumAdd )) {
			System.out.println("Existe");
		}
		else {
			System.out.println("Existe pas");
			bdd.insertDataAlbum(101, correspondance(nomChanteurAdd), nomAlbumAdd );		
			
			System.out.println("Ajout de l'album dans la base réussi");
		
		}
		
	}
	
	
	
	
	
	public void clickMeSupprAlbum(ActionEvent e) throws JsonSyntaxException, ClassNotFoundException, IOException, SQLException {
		bdd.supprAlbum(nomAlbum.getText());
		System.out.println("Suppression réussie");
	}
	
	/*
	public void clickMeSupprimerChanteur(ActionEvent e) throws JsonSyntaxException, ClassNotFoundException, IOException {

	}
	*/
	/*
	public void clickMeAjouterChanteur(ActionEvent e) throws JsonSyntaxException, ClassNotFoundException, IOException, SQLException {
		
	
		Connection conn = DriverManager.getConnection(bdd.URL, bdd.USERNAME, bdd.PASSWORD);
		String selectSQL = "SELECT * FROM album WHERE userId =" + correspondance(nomChanteur.getText());
	    Statement selectStmt = conn.createStatement();
	    ResultSet rs = selectStmt.executeQuery(selectSQL);

	    
	    while (rs.next()) {
	    	int id = rs.getInt("id");
	        int nom = rs.getInt("userId");
	        String title = rs.getString("titre");
	        System.out.println("id : " + id + " userId : " + nom + ", titre : "+ title);
	    }
	    
	    
	    rs.close();
	    selectStmt.close();
		
	}
	*/
	
	public void clickMeAffichageTable(ActionEvent e) throws JsonSyntaxException, ClassNotFoundException, IOException, SQLException {
		
		textarea.setText( bdd.tableData( nomTablePourAffichage.getText(), correspondance(recupNomChanteur.getText()) ) );
	}
	
	public void clickMeAddChanteur(ActionEvent e) throws JsonSyntaxException, ClassNotFoundException, IOException, SQLException {
		String nomChanteurAdd = tfNomChanteur.getText();
		String nomSceneAddChanteur = tfUsernameChanteur.getText();
		
		
		if ( bdd.chanteurExist( nomChanteurAdd )) {
			System.out.println("Existe déjà");
		}
		else {
			System.out.println("Existe pas");
			bdd.insertDataChanteur( nomChanteurAdd , nomSceneAddChanteur );		
			
			System.out.println("Ajout de l'album dans la base réussi");
		
		}
		
	}
	
	public void clickMeSupprChanteur(ActionEvent e) throws JsonSyntaxException, ClassNotFoundException, IOException, SQLException {
		bdd.supprChanteur(tfNomChanteur.getText());
	}
	
	/*
	public void clickMeTest(ActionEvent e) throws JsonSyntaxException, ClassNotFoundException, IOException, SQLException {
		
		bdd.idMax("album");
	}
	*/
}
