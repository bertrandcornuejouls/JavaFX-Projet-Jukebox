package Modele;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;

import javafx.scene.control.Label;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;


public class BDD {

	
	
	public static String URL = "jdbc:derby:jukeboxDB;create=true";
	public static String DRIVER = "org.apache.derby.jdbc.EmbeddedDriver";
	public static String USERNAME = "";
	public static String PASSWORD = "";
	public static String LOGIN = "";
	public static String PWD = "";

	
	
	
	public BDD() throws ClassNotFoundException, JsonSyntaxException, IOException {
		try {
			Class.forName("org.apache.derby.jdbc.ClientDriver");
			Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
			
			
		    
			//SUPPRESSION DES TABLES PRECEDEMMENT CREEE
		
			String supprTable6 = "DROP TABLE chanteur";
			PreparedStatement createTableStmt12 = conn.prepareStatement(supprTable6);
		    createTableStmt12.executeUpdate();			
			
			String supprTable5 = "DROP TABLE album";
			PreparedStatement createTableStmt11 = conn.prepareStatement(supprTable5);
		    createTableStmt11.executeUpdate();			
			
			String supprTable4 = "DROP TABLE photo";
			PreparedStatement createTableStmt10 = conn.prepareStatement(supprTable4);
		    createTableStmt10.executeUpdate();		    
			
			String supprTable3 = "DROP TABLE chanteur_company";
			PreparedStatement createTableStmt9 = conn.prepareStatement(supprTable3);
		    createTableStmt9.executeUpdate();			
			
			String supprTable2 = "DROP TABLE chanteur_adresse";
			PreparedStatement createTableStmt8 = conn.prepareStatement(supprTable2);
		    createTableStmt8.executeUpdate();			
			
			String supprTable1 = "DROP TABLE geo";
			PreparedStatement createTableStmt7 = conn.prepareStatement(supprTable1);
		    createTableStmt7.executeUpdate();
		    
		    //CREATION DES TABLES
		    
		    String createTableSQL6 = "CREATE TABLE geo (id INTEGER PRIMARY KEY, lat FLOAT, lng FLOAT)";
		    PreparedStatement createTableStmt6 = conn.prepareStatement(createTableSQL6);
		    createTableStmt6.executeUpdate();			
			
		    String createTableSQL2 = "CREATE TABLE chanteur_adresse (street VARCHAR(255), suite VARCHAR(255), city VARCHAR(255), zipcode VARCHAR(255))";
		    PreparedStatement createTableStmt2 = conn.prepareStatement(createTableSQL2);
		    createTableStmt2.executeUpdate();			
		    
		    String createTableSQL3 = "CREATE TABLE chanteur_company (nom VARCHAR(255), catchPhrase VARCHAR(255), bs VARCHAR(255))";
		    PreparedStatement createTableStmt3 = conn.prepareStatement(createTableSQL3);
		    createTableStmt3.executeUpdate();
		    
		    String createTableSQL5 = "CREATE TABLE photo (id INTEGER PRIMARY KEY, albumId INTEGER, titre VARCHAR(255), url VARCHAR(255), thumbnailUrl VARCHAR(255))";
		    PreparedStatement createTableStmt5 = conn.prepareStatement(createTableSQL5);
		    createTableStmt5.executeUpdate();
		    
		    String createTableSQL4 = "CREATE TABLE album (id INTEGER PRIMARY KEY, userId INTEGER, titre VARCHAR(255))";
		    PreparedStatement createTableStmt4 = conn.prepareStatement(createTableSQL4);
		    createTableStmt4.executeUpdate();

			String createTableSQL1 = "CREATE TABLE chanteur (id INTEGER PRIMARY KEY, nom VARCHAR(255), prenom VARCHAR(255), mail VARCHAR(255), telephone VARCHAR(255), website VARCHAR(255))";
		    PreparedStatement createTableStmt1 = conn.prepareStatement(createTableSQL1);
		    createTableStmt1.executeUpdate();

		    
		    //REMPLISSAGE DE LA TABLE chanteur + chanteur_company + chanteur_adresse :
		    
		    URL url = new URL("https://jsonplaceholder.typicode.com/users");
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			
			connection.setRequestMethod("GET");
			
			StringBuffer sb = new StringBuffer();
			
			//LECTURE DES DONNEES DU WEBSERVICE chanteur + chanteur_company + chanteur_adresse
			
		    if(connection.getResponseCode() == 200) {
				
				BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
				
				String line;
				
				while((line = in.readLine()) != null) {
					
					sb.append(line);
				}
				
				JsonElement jElement = new JsonParser().parse(sb.toString());
				
				JsonArray jArray = jElement.getAsJsonArray();
				
				//DEPOT DES DONNES DU WS DANS LA TABLE chanteur + chanteur_company + chanteur_adresse
				
		    	for(JsonElement el: jArray) {
					
					JsonObject jobject = el.getAsJsonObject();
					
					//Chanteur
					int id = jobject.get("id").getAsInt();
					String name = jobject.get("name").getAsString();
					String username = jobject.get("username").getAsString();
					String email = jobject.get("email").getAsString();
					String phone = jobject.get("phone").getAsString();
					String website = jobject.get("website").getAsString();
					
					//Adresse
					JsonObject jobject_adresse = jobject.get("address").getAsJsonObject();
					
					String street = jobject_adresse.get("street").getAsString();
					String suite = jobject_adresse.get("suite").getAsString();
					String city = jobject_adresse.get("city").getAsString();
					String zipcode = jobject_adresse.get("zipcode").getAsString();
					
					
					//Company
					JsonObject jobject_company = jobject.get("company").getAsJsonObject();

					String company_name = jobject_company.get("name").getAsString();
					String catchPhrase = jobject_company.get("catchPhrase").getAsString();
					String bs = jobject_company.get("bs").getAsString();
					
					
					//Ajout des data de l'url photo dans la table chanteur + chanteur_company + chanteur_adresse
					
					String insertSQL = "INSERT INTO chanteur (id, nom, prenom, mail, telephone, website) VALUES (?, ?, ?, ?, ?,?)";
					
					PreparedStatement insertStmt = conn.prepareStatement(insertSQL);
				   
				    insertStmt.setInt(1, id);
				    insertStmt.setString(2, name);
				    insertStmt.setString(3, username);
				    insertStmt.setString(4, email);
				    insertStmt.setString(5, phone);
				    insertStmt.setString(6, website);
				    insertStmt.executeUpdate();				    
				    
					String insertSQL1 = "INSERT INTO chanteur_adresse (street, suite, city, zipcode) VALUES (?, ?, ?, ?)";
				    PreparedStatement insertStmt1 = conn.prepareStatement(insertSQL1);
				    insertStmt1.setString(1, street);
				    insertStmt1.setString(2, suite);
				    insertStmt1.setString(3, city);
				    insertStmt1.setString(4, zipcode);
				    insertStmt1.executeUpdate();					
				    
				    String insertSQL2 = "INSERT INTO chanteur_company (nom,catchPhrase,bs) VALUES (?, ?, ?)";
				    PreparedStatement insertStmt2 = conn.prepareStatement(insertSQL2);
				    insertStmt2.setString(1, company_name);
				    insertStmt2.setString(2, catchPhrase);
				    insertStmt2.setString(3, bs);
				    insertStmt2.executeUpdate();
				    
					
				}
			}
		
		    
		    
		    //REMPLISSAGE DE LA TABLE ALBUM :
			
			URL url1 = new URL("https://jsonplaceholder.typicode.com/albums");
			HttpURLConnection connection1 = (HttpURLConnection) url1.openConnection();
			
			connection1.setRequestMethod("GET");
			
			StringBuffer sb1 = new StringBuffer();
			
			//LECTURE DES DONNEES DU WEBSERVICE ALBUM
			if(connection1.getResponseCode() == 200) {
				
				BufferedReader in = new BufferedReader(new InputStreamReader(connection1.getInputStream()));
				
				String line1;
				
				while((line1 = in.readLine()) != null) {
					
					sb1.append(line1);
				}
				
				JsonElement jElement = new JsonParser().parse(sb1.toString());
				
				JsonArray jArray = jElement.getAsJsonArray();
				
				//DEPOT DES DONNES DU WS DANS LA TABLE ALBUM
				for(JsonElement el: jArray) {
					
					JsonObject jobject = el.getAsJsonObject();
					int id = jobject.get("id").getAsInt();
					int userId = jobject.get("userId").getAsInt();
					String titre = jobject.get("title").getAsString();
					
					 //Ajout des data de l'url photo dans la table photo
					
					String insertSQL = "INSERT INTO album (id, userId, titre) VALUES (?, ?, ?)";
				    PreparedStatement insertStmt = conn.prepareStatement(insertSQL);
				    insertStmt.setInt(1, id);
				    insertStmt.setInt(2, userId);
				    insertStmt.setString(3, titre);
				    insertStmt.executeUpdate();
					
					
				}
			}			
			
			
			

			// REMPLISSAGE DE LA TABLE PHOTO
			URL url2 = new URL("https://jsonplaceholder.typicode.com/photos");
			HttpURLConnection connection2 = (HttpURLConnection) url2.openConnection();
			
			connection2.setRequestMethod("GET");
			
			StringBuffer sb2 = new StringBuffer();
			
			//LECTURE DES DONNEES DU WEBSERVICE PHOTO
			if(connection2.getResponseCode() == 200) {
				
				BufferedReader in = new BufferedReader(new InputStreamReader(connection2.getInputStream()));
				
				String line2;
				
				while((line2 = in.readLine()) != null) {
					
					sb2.append(line2);
				}
				
				JsonElement jElement = new JsonParser().parse(sb2.toString());
				
				JsonArray jArray = jElement.getAsJsonArray();
				
				//DEPOT DES DONNES DU WS DANS LA TABLE PHOTO
				for(JsonElement el: jArray) {
					
					JsonObject jobject = el.getAsJsonObject();
					int albumId = jobject.get("albumId").getAsInt();
					int id = jobject.get("id").getAsInt();
					String titre = jobject.get("title").getAsString();
					String urle = jobject.get("url").getAsString();
					String thumb = jobject.get("thumbnailUrl").getAsString();
					
					 //Ajout des data de l'url photo dans la table photo
					
					String insertSQL10 = "INSERT INTO photo (albumId, id, titre, url, thumbnailUrl) VALUES (?, ?, ?, ?, ?)";
				    PreparedStatement insertStmt10 = conn.prepareStatement(insertSQL10);
				    insertStmt10.setInt(1, albumId);
				    insertStmt10.setInt(2, id);
				    insertStmt10.setString(3, titre);
				    insertStmt10.setString(4, urle);
				    insertStmt10.setString(5, thumb);
				    insertStmt10.executeUpdate();
					
					
				}
			}

		    conn.close();
		} catch (SQLException e) {
		      e.printStackTrace();
	    }
	}
	
	
	
	   public static void ConnectBDD() {
	       try {
	           Class.forName(DRIVER);
	           Connection cn = DriverManager.getConnection(URL, LOGIN, PWD);
	           System.out.println("Connection à la base de données");
	           //Statement st = cn.createStatement();
	           //st.execute("create table eleve (code int, nom varchar(20), prenom varchar(20))");
	           //st.executeUpdate("INSERT INTO eleve VALUES (1, 'DURAND','Jacques')");
	           //st.executeUpdate("INSERT INTO eleve VALUES (2, 'DUPOND','Daniel')");
	       }catch (ClassNotFoundException e) {
	            
	               e.printStackTrace();
	           }

	           catch (SQLException e) {
	        	   e.printStackTrace();
	           }
	   }
	   
	   
	   //Export CSV des albums
	   public void csvPrintAlbum(int idChanteur) throws IOException, SQLException {
			//FICHIER CSV ECRITURE
			BufferedWriter writer = new BufferedWriter(new FileWriter("data.csv"));
			// écrire une ligne de titres
			writer.write("ID ; userID ; Titre\n");			
			
			Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
			
			String selectSQL = "SELECT * FROM album WHERE userId ="+idChanteur;
		    Statement selectStmt = conn.createStatement();
		    ResultSet rs = selectStmt.executeQuery(selectSQL);
		   
		    
		    while (rs.next()) {
		       	int id = rs.getInt("id");
		        int nom = rs.getInt("userId");
		        String title = rs.getString("titre");
		        writer.write(id + " ; " + nom + " ; " + title+"\n");
		    }
		    rs.close();
		    selectStmt.close();
			
			// fermer le writer une fois que vous avez fini d'écrire
			writer.close();
	   }
	   
	   
	   
	   public static boolean albumExist(int idChanteur, String titreAlbum) throws SQLException {			
			Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);			
			String selectSQL = "SELECT * FROM album WHERE userId ="+idChanteur; // + "AND titre = "+titreAlbum;
	
		    Statement selectStmt = conn.createStatement();
		    
		    ResultSet rs = selectStmt.executeQuery(selectSQL);
		       
		    //rs.next();
		    
		    /*
		    int id = rs.getInt("id");
	        int nom = rs.getInt("userId");
	        String title = rs.getString("titre");
		    */
		    boolean b = false;
	        while (rs.next()) {
	        	//int idd = rs.getInt("id");
		        //int userid = rs.getInt("userId");
		        //String titre = rs.getString("titre");
		        //System.out.println(idd + " ; " + userid + " ; " + titre+"\n");
	        	if(rs.getString("titre").equals(titreAlbum)) {
	        		b = true;
	        	}
	        }
	        
	        /*
	        if(rs.getInt("userId") == idChanteur && rs.getString("titre").equals(titreAlbum) ) {
			   // Album présent avec le nom entré par l'utilisateur
			   System.out.println("Chanteur et album présents");
			   return true;
		   }
		   else {
			   System.out.println("Chanteur et album absents");
			   return false;
		   }
		   */
		   return b;		   
	   }
	   
	   
	   public void labelInformation(Label lab, String string) {
		   lab.setText(string);
	   }
	   
	   /*
	   //Pour ensuite pouvoir avoir un id unique dynamique à la génération d'une nouvelle entité
	   public int idMax(String tableName) throws SQLException {
		   
		   Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);			
		   
		   
		   String selectSQL = "SELECT MAX (id) FROM album";

		   Statement selectStmt = conn.createStatement();
		   
		   ResultSet rs = selectStmt.executeQuery(selectSQL);
		   
		   rs.next();
		   //int res = rs.getInt("id");

		   System.out.println("resultSet = "+ rs);
		   
		   return 0;
	   }
	   */
	   public void insertDataAlbum(int idAlbum, int idChanteur, String nomAlbum) throws SQLException {
		   Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);			
		   
		   
		   String selectSQL = "INSERT INTO album VALUES ("+Integer.toString(idAlbum)+"," +Integer.toString(idChanteur)+","+ "'"+nomAlbum+"')";
			
		    Statement selectStmt = conn.createStatement();
		    
		    int rs = selectStmt.executeUpdate(selectSQL);
		    /*
		    String selectSQL1 = "SELECT * FROM album";
		    Statement selectStmt1 = conn.createStatement();
		    
		    ResultSet rs1 = selectStmt1.executeQuery(selectSQL1);
		    
		    
		    while (rs1.next()) {
	        	int idd = rs1.getInt("id");
		        int userid = rs1.getInt("userId");
		        String titre = rs1.getString("titre");
		        System.out.println(idd + " ; " + userid + " ; " + titre+"\n");
	        	
	        }
		    */
		       
	   }
	   
	   
	   
	   public void supprAlbum(String nomAlbum) throws SQLException {
		   Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);			
		   
		   
			String selectSQL = "DELETE FROM album WHERE titre = '"+nomAlbum +"' ";
	
			Statement selectStmt = conn.createStatement();
		    
		    int rs = selectStmt.executeUpdate(selectSQL);
	   }
	   
	   
	   public String tableData(String tableName, int chanteurId) throws SQLException {
		   
		   if (tableName.equals("album")) {
			   String Sretour = "Id, chanteurId, nomAlbum \n";
			   Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
			   String selectSQL = "SELECT * FROM "+tableName +" WHERE userId ="+chanteurId;
			   Statement selectStmt = conn.createStatement();
			    
			   ResultSet rs1 = selectStmt.executeQuery(selectSQL);
			   
			   while (rs1.next()) {
		        	int id = rs1.getInt("id");
			        int userid = rs1.getInt("userId");
			        String titre = rs1.getString("titre");
			        Sretour = Sretour + id + " ; " + userid + " ; " + titre+"\n";	        	
		       }   
			   return Sretour;   
		   }
		   else {
			   String Sretour = "Id, Nom, Nom de scène \n";
			   Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
			   String selectSQL = "SELECT * FROM chanteur";
			   Statement selectStmt = conn.createStatement();
			    
			   ResultSet rs = selectStmt.executeQuery(selectSQL);
			   
			   while (rs.next()) {
		        	int id = rs.getInt("id");
			        String name = rs.getString("nom");
			        String username = rs.getString("prenom");
			        Sretour = Sretour + id + " ; " + name + " ; " + username+"\n";	        	
		       }   
			   return Sretour; 
		   }
	   }
	   
	   
	   public void insertDataChanteur(String nomChanteur, String nomSceneChanteur) throws SQLException {
		   Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);			
		   
		   String selectSQL = "INSERT INTO chanteur VALUES ("+Integer.toString(11) +","+"'" +nomChanteur+"'"+","+ "'"+nomSceneChanteur+"'"+","+"'"+"test"+"'"+","+"'"+"test"+"'"+","+"'"+"test"+"')";
		   
		    Statement selectStmt = conn.createStatement();
		    
		    int rs = selectStmt.executeUpdate(selectSQL);
		    
		    String selectSQL1 = "SELECT * FROM album";
		    Statement selectStmt1 = conn.createStatement();
		    
		    ResultSet rs1 = selectStmt1.executeQuery(selectSQL1);		       
	   }

	   public void supprChanteur(String nomChanteur) throws SQLException {
		   
		   Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);			
		   
		   
			String selectSQL = "DELETE FROM chanteur WHERE nom = '"+nomChanteur +"' ";
	
			Statement selectStmt = conn.createStatement();
		    
		    int rs = selectStmt.executeUpdate(selectSQL);
		    
	   }

	   
	   
	   public static boolean chanteurExist(String nomChanteur) throws SQLException {			
			Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);			
			String selectSQL = "SELECT * FROM chanteur";
	
		    Statement selectStmt = conn.createStatement();
		    
		    ResultSet rs = selectStmt.executeQuery(selectSQL);

		    boolean b = false;
	        while (rs.next()) {
	        	if(rs.getString("nom").equals(nomChanteur)) {
	        		b = true;
	        	}
	        }

		   return b;		   
	   }

}
